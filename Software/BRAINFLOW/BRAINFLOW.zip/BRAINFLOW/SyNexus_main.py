import sys
from PyQt5.QtWidgets import (QApplication, QWidget, QVBoxLayout, QPushButton, QLabel)
from PyQt5.QtCore import Qt
from SyNexus_cursor_gui import CursorWindow


class MainWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("SyNexus: Adaptive BCI Control")
        self.setFixedSize(750, 550)
        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(30, 30, 30, 30)

        title = QLabel("SyNexus")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 60px; font-weight: bold;")
        layout.addWidget(title)

        # TODO: pick final subtitle
        subtitle = QLabel("Cursor Control Interface for BCI System")
        subtitle.setAlignment(Qt.AlignCenter)
        subtitle.setStyleSheet("color: gray; font-size: 30px")
        layout.addWidget(subtitle)

        layout.addStretch()

        cursor_button = QPushButton("Start Cursor Control Session")
        cursor_button.setMinimumHeight(85)
        cursor_button.setStyleSheet("font-size: 20px;")
        cursor_button.clicked.connect(self.open_cursor_control)
        layout.addWidget(cursor_button)

        layout.addStretch()

        self.status_label = QLabel("Board status: not connected")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color: gray; font-size: 18px;")
        layout.addWidget(self.status_label)

        self.setLayout(layout)

    def open_cursor_control(self):
        # Front-end-only mock-up: no real board connection is attempted here.
        self.cursor_window = CursorWindow()
        self.cursor_window.show()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())
