import sys
import random

# PyQt5 for the control panel window
from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QPushButton, QApplication
)
from PyQt5.QtCore import QTimer, Qt

# PyAutoGUI for moving the real system mouse cursor
import pyautogui

# Mock directions used only to populate the prediction label for
# screenshot/demo purposes. No real EEG acquisition or classification
# takes place in this file - the direction is picked at random, but the
# resulting cursor movement on screen is real.
MOCK_DIRECTIONS = ["up", "down", "left", "right"]

# Movement step in pixels per mock prediction
CURSOR_STEP = 50

# Matches the 4 s analysis window planned for the real classifier
MOCK_INTERVAL_MS = 4000

# Fail-safe: moving the mouse to a screen corner (e.g. top-left) raises
# a pyautogui.FailSafeException and stops the program, so you are never
# stuck if the mock cursor movement gets in the way.
pyautogui.FAILSAFE = True


class CursorWindow(QWidget):
    """
    Front-end-only mock-up of the SyNexus real-time cursor control panel.
    Reproduces the layout and interaction flow of the planned system
    (Start/Stop, live prediction display) without any board connection,
    signal acquisition, or classifier logic. Intended purely to produce
    screenshots for the presentation and poster.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("SyNexus - Cursor Control")
        self.setFixedSize(400, 300)

        self.timer = QTimer()
        self.timer.timeout.connect(self._mock_predict)

        self._build_ui()

    def _build_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.setContentsMargins(30, 30, 30, 30)

        title = QLabel("Cursor Control")
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("font-size: 16px; font-weight: bold;")
        layout.addWidget(title)

        self.status_label = QLabel("System inactive")
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("font-size: 13px; color: gray;")
        layout.addWidget(self.status_label)

        self.prediction_label = QLabel("Prediction: \u2014")
        self.prediction_label.setAlignment(Qt.AlignCenter)
        self.prediction_label.setStyleSheet("font-size: 13px;")
        layout.addWidget(self.prediction_label)

        self.start_button = QPushButton("Start")
        self.start_button.setMinimumHeight(50)
        self.start_button.setStyleSheet("background-color: #2ca02c; color: white; font-size: 14px;")
        self.start_button.clicked.connect(self._start_control)
        layout.addWidget(self.start_button)

        self.stop_button = QPushButton("Stop")
        self.stop_button.setMinimumHeight(50)
        self.stop_button.setStyleSheet("background-color: #d62728; color: white; font-size: 14px;")
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self._stop_control)
        layout.addWidget(self.stop_button)

        self.setLayout(layout)

    def _start_control(self):
        self.start_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self.status_label.setText("System active - BCI controlling cursor")
        self.status_label.setStyleSheet("font-size: 13px; color: green;")
        self.timer.start(MOCK_INTERVAL_MS)

    def _stop_control(self):
        self.timer.stop()
        self.start_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.status_label.setText("System inactive")
        self.status_label.setStyleSheet("font-size: 13px; color: gray;")
        self.prediction_label.setText("Prediction: \u2014")

    def _mock_predict(self):
        """Picks a random direction (no real signal is read) and moves the
        system cursor accordingly, so the demo/screenshot shows an actual
        moving pointer rather than just a changing label."""
        direction = random.choice(MOCK_DIRECTIONS)
        self.prediction_label.setText(f"Prediction: {direction}")

        try:
            if direction == "up":
                pyautogui.moveRel(0, -CURSOR_STEP)
            elif direction == "down":
                pyautogui.moveRel(0, CURSOR_STEP)
            elif direction == "left":
                pyautogui.moveRel(-CURSOR_STEP, 0)
            elif direction == "right":
                pyautogui.moveRel(CURSOR_STEP, 0)
        except pyautogui.FailSafeException:
            # Triggered by moving the mouse to a screen corner
            self._stop_control()


# Quick standalone test: python SyNexus_cursor_gui.py
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = CursorWindow()
    window.show()
    sys.exit(app.exec_())
